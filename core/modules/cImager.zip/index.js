_.core(function(){
	
	_.cImager.replace({input:"image"});
})