<!doctype html>
<html>
	<head>
		<meta charset='utf-8'/>
		<title> cImager test</title>
		
		<script src='/core/lib/js/retarcore.js'> </script>
		<script src='/core/modules/cImager/controller.js'> </script>
		<script src='index.js'> </script>
	</head>
	
	
	<body>
		<h1> cImager testing </h1>
	
			<input type='hidden' id='image' value='19'/>

	</body>
</html>